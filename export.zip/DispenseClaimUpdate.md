## {{page-title}}

| FHIR Exchange | API | FHIR Resource |
|--
| FHIR RESTful | <a href="https://digital.nhs.uk/developer/api-catalogue/electronic-prescription-service-fhir#api-Dispensing-send-dispense-claim-message">PUT /Claim/(id)</a> | {{pagelink:NHSDigital-Claim.md }} |


<br>

This interaction is used to re-submit (i.e. amend) a previously sent `dispense-claim` to NHS BSA.