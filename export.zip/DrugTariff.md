#### Drug Tariff

Key information held in the Drug Tariff can be accessed online through a special viewer on the [NHS BSA website](https://www.nhsbsa.nhs.uk/pharmacies-gp-practices-and-appliance-contractors/drug-tariff) (select View XXX Drug Tariff Online).



