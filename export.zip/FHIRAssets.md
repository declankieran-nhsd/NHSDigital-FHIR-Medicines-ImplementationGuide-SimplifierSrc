## FHIR Assets

This section lists all the FHIR assets which are available in this Implementation Guide.

These Assets are:

{{index:current}}
