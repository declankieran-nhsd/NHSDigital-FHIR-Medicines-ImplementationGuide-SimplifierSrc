## FHIR STU3 to R4 Conversion

Structural (schema) differences between HL7 FHIR STU3 and R4 are documented [Differences from Release 3](https://www.hl7.org/fhir/diff.html)

### CareConnect and NHSDigital/UKCore Differences




