### Message dispense-notification

- {{pagelink:prescription-dispense-notification.md}} Partial dispensed prescription
- {{pagelink:1stdispenseevent-partial}}
- {{pagelink:2nddispenseevent-partial}}
- {{pagelink:3rddispenseevent-completed}}
- {{pagelink:1stdispenseevent-partialwithPatientResource}}