#### Profiles

- {{pagelink:NHSDigital-Claim.md}}
- [NHSDigital-CommunicationRequest](https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/Profiles/NHSDigital-CommunicationRequest.guide.md)
- {{pagelink:NHSDigital-MedicationDispense}}
- {{pagelink: NHSDigital-MedicationRequest.md}}
- {{pagelink: DM-MedicationRequest-Outcome.md}}
- {{pagelink: UKCore-List}}
- [NHSDigital-Patient](https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/Profiles/NHSDigital/NHSDigital-Patient.guide.md)
- {{pagelink: DM-MedicationRequest-Medication.md}}
- {{pagelink: DM-MedicationDispense-Medication.md}}
- {{pagelink: NHSDigital-Task.md}}