## {{page-title}}

| FHIR Exchange | API | FHIR Resource |
|--
| FHIR RESTful | <a href="https://digital.nhs.uk/developer/api-catalogue/electronic-prescription-service-fhir#api-Dispensing-send-dispense-claim-message">POST /Claim</a> | {{pagelink:NHSDigital-Claim-duplicate-4 }} |


<br>

This interaction is used to submit a prescription claim to NHS BSA and submit an amended Claim.