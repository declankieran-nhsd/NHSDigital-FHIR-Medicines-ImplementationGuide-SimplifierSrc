## {{page-title}}

| FHIR Exchange | API | FHIR Operation Definition |
|--
| FHIR Operation  | [POST /$prepare](https://digital.nhs.uk/developer/api-catalogue/electronic-prescription-service-fhir#api-Prescribing-prepare-prescription) | {{pagelink:prepare-duplicate-2}} |

<br>

A prescription must be signed before it can be sent to EPS and Pharmacists.