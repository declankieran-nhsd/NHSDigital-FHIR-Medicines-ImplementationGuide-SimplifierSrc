### Message prescription-order-response

- {{pagelink:PrescriptionOrderHomecareResponse-duplicate-2}} homecare order cancellation response example.
- {{pagelink:PrescriptionOrderHomecaseSubsequentResponse-duplicate-2}} Subsequent message received after the prescription was returned unissued by pharmacist.

<br />