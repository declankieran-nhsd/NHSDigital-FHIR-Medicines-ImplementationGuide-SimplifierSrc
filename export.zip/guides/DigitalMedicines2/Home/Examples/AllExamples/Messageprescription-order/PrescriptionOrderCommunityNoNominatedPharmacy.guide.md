### Prescription Order Community No Nominated Pharmacy

Community repeat dispensing prescription, no nominated pharmacy

<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:Bundle-aef77afb-7e3c-427a-8657-2c427f71a271}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:Bundle-aef77afb-7e3c-427a-8657-2c427f71a271}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:Bundle-aef77afb-7e3c-427a-8657-2c427f71a271}}
    </div>
  </div>
</div>
