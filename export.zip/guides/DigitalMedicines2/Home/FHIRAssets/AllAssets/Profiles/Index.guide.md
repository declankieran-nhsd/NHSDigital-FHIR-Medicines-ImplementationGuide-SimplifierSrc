### Profiles

- {{pagelink:NHSDigital-Claim-duplicate-4}}
- [NHSDigital-CommunicationRequest](https://simplifier.net/guide/nhsdigital/home/fhirassets/allassets/profiles/nhsdigital-communicationrequest)
- {{pagelink:NHSDigital-MedicationDispense-duplicate-3}}
- {{pagelink: NHSDigital-MedicationRequest-duplicate-3}}
- {{pagelink: DM-MedicationRequest-Outcome-duplicate-2}}
- {{pagelink: UKCore-List-duplicate-2}}
- [NHSDigital-Patient](https://simplifier.net/guide/nhsdigital/home/fhirassets/allassets/profiles/nhsdigital-patient)
- {{pagelink: DM-MedicationRequest-Medication-duplicate-3}}
- {{pagelink: DM-MedicationDispense-Medication-duplicate-3}}
- {{pagelink: NHSDigital-Task-duplicate-2}}

@``` 
from
    StructureDefinition
select
    *
order by
    name
```