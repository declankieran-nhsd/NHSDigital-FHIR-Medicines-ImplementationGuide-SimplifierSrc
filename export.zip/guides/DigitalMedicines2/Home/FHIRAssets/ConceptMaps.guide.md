## ConceptMaps

The following ConceptMaps are defined in this implementation Guide.

|Profile|Description|
|--
| {{pagelink:ukcore-prescriptiontypetor4prescriptiontherapytypemap-duplicate-2}} | CareConnect/UK Core to Digital Medicine conversion | 
| {{pagelink:MedicationRequest-course-therapy-type-map-duplicate-3}} ||
| {{pagelink:Prescription-release-rejection-reason-EPS-IssueCode-duplicate-2}} || 
